#' A function that generates a sequence of states
#'
#' @param s Original time series
#' @param q Quantiles parameter
#'
#' @return States series
#' @export
#'
#' @examples
quantilestate<-function(s,q){
  #将时间序列转换为状态序列，其中状态由正整数定义
  n=length(q)
  qs=quantile(s,p=q)
  ss=matrix(0,c(n+1),1)
  ss[1:n]=as.matrix(qs)
  ss[c(n+1)]=max(s)
  ns=length(s)
  s01=matrix(0,ns,1)
  for(i in 1:ns){
    s01[i]=length(which(ss<s[i]))+1
  }
  return(s01)
}
