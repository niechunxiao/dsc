#' Average dynamics similarity coefficient
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param sn The number of states.
#' @param lagmin The minimum value of lag.
#' @param lagmax The maximum value of lag.
#' @param th0 Threshold parameter (one vector).
#'
#' @return Average dynamics similarity coefficient
#' @export
#'
#' @examples
avedscoef<-function(s1,s2,sn,lagmin,lagmax,th0){
  #变化滞后阶
  nlag=seq(lagmin,lagmax,1)
  m=length(nlag)

  coe=matrix(0,m,1)
  for(i in 1:m){
    coe[i]=dscoef(s1,s2,sn,nlag[i],th0)$dsc
  }

  dsc=cbind(nlag,coe)
  avedsc=mean(coe)
  output=list(avedsc=avedsc,dsc=dsc)
  return(output)
}
