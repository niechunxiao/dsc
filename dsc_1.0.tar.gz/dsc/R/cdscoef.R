#' Cross dynamic similarity coefficient
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param sn The number of states.
#' @param lags01 Threshold parameter (the first time series).
#' @param lags02 Threshold parameter (the second time series).
#' @param th0 Threshold parameter (one vector)
#'
#' @return Cross dynamic similarity coefficient
#' @export
#'
#' @examples
cdscoef<-function(s1,s2,sn,lags01,lags02,th0){
  #Cross dynamic similarity coefficient.
  q0=seq(1/sn,c(1-1/sn),1/sn)
  net1=quantilegraph(s1,q0,lags01)
  net2=quantilegraph(s2,q0,lags02)
  adj01=thnet(net1,th0)
  adj02=thnet(net2,th0)
  n=length(th0)
  jac=matrix(0,n,1)
  for(i in 1:n){
    jac[i]=jaccardind(adj01[,,i],adj02[,,i])
  }
  mjac=mean(jac)
  output=list(coef=mjac,jac=jac)
  return(output)
}
