#' Jaccard similarity between quantile graph sequences.
#'
#' @param net1 The quantile graph sequence of the first time series.
#' @param net2 The quantile graph sequence of the second time series.
#' @param i The i-th graph.
#' @param th0 The parameters of the threshold graphs (vector).
#'
#' @return The similarity between the i-th graphs of two graph sequences.
#' @export
#'
#' @examples
netseqjaccardind<-function(net1,net2,i,th0){
  adj01i=thnet(net1[,,i],th0)
  adj02i=thnet(net2[,,i],th0)
  n=length(th0)
  jaci=matrix(0,n,1)
  for(i in 1:n){
    jaci[i]=jaccardind(adj01i[,,i],adj02i[,,i])
  }
  return(jaci)
}
