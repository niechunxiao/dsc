#' Quantile graph of multi-dimensional time series
#'
#' @param s A time series matrix, where each column corresponds to a series.
#' @param sn The number of states.
#' @param lags Lag.
#'
#' @return A three-dimensional matrix including quantile graphs between different time series.
#' @export
#'
#' @examples
multiquantilegraph<-function(s,sn,lags){
  #计算多维时间序列的分位数图
  n=dim(s)
  n1=n[1]
  n2=n[2]
  L=matrix(c(rep(1:n2, each = n2), rep(1:n2, times = n2)), ncol = 2)
  nL=dim(L)
  nL1=nL[1]
  pmat=array(0,dim=c(sn,sn,nL1))
  for(i in 1:nL1){
    pmat[,,i]=crossnet(s[,L[i,1]],s[,L[i,2]],sn,lags)
  }
  return(pmat)
}
