#' DSC of multi-dimensional time series
#'
#' @param s1 The first multi-dimensional time series, where each column corresponds to a time series.
#' @param s2 The second multi-dimensional time series, where each column corresponds to a time series.
#' @param sn The number of states.
#' @param lags Lag.
#' @param th0 The parameters of the threshold graph (vector).
#'
#' @return A list that includes a sequence of quantile graphs and DSC.
#' @export
#'
#' @examples
multiseriesdscoef<-function(s1, s2, sn, lags, th0){
  net1=multiquantilegraph(s1,sn,lags)
  net2=multiquantilegraph(s2,sn,lags)
  m=length(th0)
  n=dim(net1)
  jac=matrix(0,m,n[3])
  for(i in 1:n[3]){
    jac[,i]=netseqjaccardind(net1,net2,i,th0)
  }
  mjac=matrix(0,n[3],1)
  for(i in 1:n[3]){
    mjac[i,1]=mean(jac[,i])
  }
  multcoe=mean(mjac)
  output=list(net1=net1,net2=net2,jac=jac,mjac=mjac,multcoe=multcoe)
  return(output)
}
