#' Cross dynamic similarity coefficient matrix
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param sn The number of states.
#' @param lags Threshold parameter
#' @param th0 Threshold parameter (one vector).
#'
#' @return Cross dynamic similarity coefficient matrix
#' @export
#'
#' @examples
cdscoefmatrix<-function(s1,s2,sn,lags,th0){
  mat=matrix(0,lags,lags)
  for(i in 1:lags){
    for(j in 1:lags){
      mat[i,j]=cdscoef(s1,s2,sn,i,j,th0)$coef
    }
  }
  return(mat)
}
