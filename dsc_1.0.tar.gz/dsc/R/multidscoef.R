#' Multi-scale dynamics similarity coefficient
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param snmin The minimum number of states.
#' @param snmax The maximum number of states.
#' @param lags Lag (A positive integer).
#' @param nth The number of thresholds (A positive integer).
#'
#' @return Multi-scale dynamics similarity coefficient
#' @export
#'
#' @examples
multidscoef<-function(s1,s2,snmin,snmax,lags,nth){
  #变化划分状态数目，snmin和snmax分别是最小的状态数目和最大的状态数目
  #nth是阈值划分的数目，注意计算时是乘以该数再减1
  sn=seq(snmin,snmax,1)
  m=length(sn)
  coe=matrix(0,m,1)
  for(i in 1:m){
    coe[i]=dscoef(s1,s2,sn[i],lags,seq(0,1/sn[i],1/(sn[i]*nth-1)))$dsc
  }
  dsc=cbind(sn,coe)
  multidsc=mean(coe)
  output=list(multidsc=multidsc,dsc=dsc)
  return(output)
}
