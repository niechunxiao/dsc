#' Cross transition frequency matrix
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param sn The number of states.
#' @param lags Lag.
#'
#' @return The transition frequency matrix from s1 to s2.
#' @export
#'
#' @examples
crossnet<-function(s1,s2,sn,lags){
  #方向s1-s2，sn为状态数目
  n=length(s1)
  q0=seq(1/sn,c(1-1/sn),1/sn)
  s11=quantilestate(s1,q0)
  s21=quantilestate(s2,q0)
  x1=s11[1:c(n-lags)]
  x2=s21[c(lags+1):n]
  xx=cbind(x1,x2)
  nq=length(q0)+1
  smat=matrix(0,nq,nq)
  for(i in 1:nq){
    for(j in 1:nq){
      smat[i,j]=length(intersect(which(xx[,1]==i),which(xx[,2]==j)))
    }
  }
  sp=matrix(0,nq,nq)
  for(i in 1:nq){
    sp[i,]=smat[i,]/sum(smat[i,])
  }
  return(sp)
}
