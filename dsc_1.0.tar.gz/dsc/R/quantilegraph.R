#' Quantile Graph
#'
#' @param x time series
#' @param q Quantile parameter
#' @param lags lag
#'
#' @return Quantile graph
#' @export
#'
#' @examples
quantilegraph<-function(x,q,lags){
  #生成状态转移网络，其中不同状态之间的转移矩阵作为有权的邻接矩阵
  n=length(x)
  x0=quantilestate(x,q)
  x1=x0[1:c(n-lags)]
  x2=x0[c(lags+1):n]
  xx=cbind(x1,x2)
  nq=length(q)+1
  smat=matrix(0,nq,nq)
  for(i in 1:nq){
    for(j in 1:nq){
      smat[i,j]=length(intersect(which(xx[,1]==i),which(xx[,2]==j)))
    }
  }
  sp=matrix(0,nq,nq)
  for(i in 1:nq){
    sp[i,]=smat[i,]/sum(smat[i,])
  }
  return(sp)
}
