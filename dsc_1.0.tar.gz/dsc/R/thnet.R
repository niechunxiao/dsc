#' Threshold network
#'
#' @param qg Quantile graph with transition probability
#' @param th0 Threshold
#'
#' @return Adjacency matrix (0-1 matrix)
#' @export
#'
#' @examples
thnet<-function(qg,th0){
  n=length(th0)
  m=dim(qg)
  adj=array(0,dim=c(m[1],m[2],n))
  for(i in 1:n){
    adj[,,i]=ifelse(qg>th0[i],1,0)
  }
  return(adj)
}
