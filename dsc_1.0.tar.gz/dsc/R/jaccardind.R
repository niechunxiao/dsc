#' Jaccard similarity
#'
#' @param adj1 Adjacency matrix
#' @param adj2 Adjacency matrix
#'
#' @return Jaccard similarity
#' @export
#'
#' @examples
jaccardind<-function(adj1,adj2){
  #This is a function used to calculate the Jaccard similarity between networks.
  #The symbols adj1 and adj2 represent the adjacency matrices of the two networks.
  n1=sum(adj1+adj2)
  adjprod=adj1*adj2
  n2=sum(adjprod)
  jaccard=n2/(n1-n2)
  return(jaccard)
}
