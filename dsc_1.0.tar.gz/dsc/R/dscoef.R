#' Dynamics similarity coefficient
#'
#' @param s1 The first time series.
#' @param s2 The second time series.
#' @param sn The number of states.
#' @param lags Lag
#' @param th0 Threshold parameter (one vector)
#'
#' @return Dynamics similarity coefficient
#' @export
#'
#' @examples
dscoef<-function(s1,s2,sn,lags,th0){
  #Dynamics similarity coefficient.
  #sn是状态数目
  q0=seq(1/sn,c(1-1/sn),1/sn)
  net1=quantilegraph(s1,q0,lags)
  net2=quantilegraph(s2,q0,lags)
  adj01=thnet(net1,th0)
  adj02=thnet(net2,th0)
  n=length(th0)
  jac=matrix(0,n,1)
  for(i in 1:n){
    jac[i]=jaccardind(adj01[,,i],adj02[,,i])
  }
  mjac=mean(jac)
  output=list(dsc=mjac,jac=jac)
  return(output)
}
